export const  Clients = [
    {
      image: 'https://static.vecteezy.com/system/resources/previews/023/871/270/original/jordan-brand-logo-symbol-with-name-red-design-clothes-sportwear-illustration-free-vector.jpg',
    },
    {
      image: 'https://www.creativefabrica.com/wp-content/uploads/2020/03/08/Service-industry-engineering-design-logo-Graphics-3394629-1.jpg',
    },
    {
     
      image: 'https://static.vecteezy.com/system/resources/previews/020/336/369/original/mi-xiaomi-logo-mi-xiaomi-icon-free-free-vector.jpg',
    },
    {
      image:'https://tse4.mm.bing.net/th/id/OIP.02fJZ0ZhxMG-yrFZ1YoDHQHaDF?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    },
    

     {
      image:'https://masterbundles.com/wp-content/uploads/2022/10/293-951.jpg',
    },
     {
      image:'https://images.creativemarket.com/0.1.0/ps/7536267/1820/1214/m1/fpnw/wm0/logo-template-v.2-56-.jpg?1578112807&s=999b9f10fa3b98c45fc7c26d7cda7b33',
    },

  ];
 